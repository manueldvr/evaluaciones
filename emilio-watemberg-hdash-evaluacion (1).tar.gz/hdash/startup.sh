java -jar  target/hdash-0.0.1-SNAPSHOT.jar
