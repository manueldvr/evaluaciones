package com.despegar.examen.hdash.api.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.despegar.examen.hdash.domain.AvailabilitiesHotelWrapper;
import com.despegar.examen.hdash.service.HotelService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = HotelController.class, secure = false)
public class HotelControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private HotelService hotelService;

	@Before
	public void setUp() {
	}

	@Test
	public void getTotalCountByScopeTest() throws Exception {
		Map<String, Long> map = new HashMap<>();
		map.put("1", 2L);
		Mockito.when(hotelService.getTotalHotelsByScope(Mockito.anyObject())).thenReturn(map);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/dashboard/hotels")
				.accept(MediaType.APPLICATION_JSON).param("scope", "cities");
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse().getContentAsString());
		String expected = "[{\"1\":2}]";
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

	@Test
	public void getAvailabilitiesByScopeTest() throws Exception {
		Map<String, Long> map = new HashMap<>();
		map.put("1", 2L);
		List<String> unavailables = new ArrayList<>();
		unavailables.add("33");
		AvailabilitiesHotelWrapper availabilitiesHotelWrapper = new AvailabilitiesHotelWrapper(map,unavailables); 
		Mockito.when(hotelService.getTotalOfAvailabilitiesHotelsByScope(Mockito.anyObject(),Mockito.anyObject())).thenReturn(availabilitiesHotelWrapper);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/dashboard/availabilities")
				.accept(MediaType.APPLICATION_JSON).param("scope", "cities").param("destinations", "1");
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse().getContentAsString());
		String expected = "[{\"availables\":[{\"1\":2}],\"unavailables\":[\"33\"]}]";
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

}
