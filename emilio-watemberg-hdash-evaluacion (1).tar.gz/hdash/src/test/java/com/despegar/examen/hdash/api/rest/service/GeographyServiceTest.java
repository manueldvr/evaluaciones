package com.despegar.examen.hdash.api.rest.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.util.UriComponentsBuilder;

import com.despegar.examen.hdash.domain.City;
import com.despegar.examen.hdash.domain.Continent;
import com.despegar.examen.hdash.domain.Country;
import com.despegar.examen.hdash.repository.ApiClient;
import com.despegar.examen.hdash.service.impl.GeographyServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootConfiguration()
public class GeographyServiceTest {

	@Mock
	private ApiClient apiClient;

	@InjectMocks
	private GeographyServiceImpl geographyService;

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(geographyService, "cityApi", "http://despegar.com/cities");
		ReflectionTestUtils.setField(geographyService, "countryApi", "http://despegar.com/countries");
		ReflectionTestUtils.setField(geographyService, "continentApi", "http://despegar.com/continents");
	}

	@Test
	public void getAllCitiesTest() throws Exception {

		List<City> cities = new ArrayList<>();
		City cityA = new City(1L, 2L);
		City cityB = new City(2L, 2L);
		City cityC = new City(3L, 2L);
		cities.add(cityA);
		cities.add(cityB);
		cities.add(cityC);

		Mockito.when(apiClient.getListDataSync(Mockito.any(UriComponentsBuilder.class), Mockito.eq(City.class)))
				.thenReturn(cities);

		List<City> respuesta = geographyService.getAllCities();
		assertNotNull(respuesta);
		assertSame(respuesta.get(0).getId(), 1L);
	}
	
	@Test
	public void getAllCountriesTest() throws Exception {

		List<Country> countries = new ArrayList<>();
		Country countryA = new Country(1L, 2L, "AR");
		Country countryB = new Country(2L, 2L, "US");
		Country countryC = new Country(3L, 2L, "CO");
		countries.add(countryA);
		countries.add(countryB);
		countries.add(countryC);

		Mockito.when(apiClient.getListDataSync(Mockito.any(UriComponentsBuilder.class), Mockito.eq(Country.class)))
				.thenReturn(countries);

		List<Country> respuesta = geographyService.getAllCountries();
		assertNotNull(respuesta);
		assertSame(respuesta.get(0).getId(), 1L);
	}
	
	@Test
	public void getAllContinentsTest() throws Exception {

		List<Continent> continents = new ArrayList<>();
		Continent continentA = new Continent(1L, "2");
		Continent continentB = new Continent(2L, "2");
		Continent continentC = new Continent(3L, "2");
		continents.add(continentA);
		continents.add(continentB);
		continents.add(continentC);

		Mockito.when(apiClient.getListDataSync(Mockito.any(UriComponentsBuilder.class), Mockito.eq(Continent.class)))
				.thenReturn(continents);

		List<Continent> respuesta = geographyService.getAllContinents();
		assertNotNull(respuesta);
		assertSame(respuesta.get(0).getId(), 1L);
	}

}
