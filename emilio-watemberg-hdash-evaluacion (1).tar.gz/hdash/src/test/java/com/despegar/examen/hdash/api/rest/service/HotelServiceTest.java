package com.despegar.examen.hdash.api.rest.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.util.UriComponentsBuilder;

import com.despegar.examen.hdash.domain.AvailabilitiesHotelWrapper;
import com.despegar.examen.hdash.domain.City;
import com.despegar.examen.hdash.domain.Hotel;
import com.despegar.examen.hdash.domain.Location;
import com.despegar.examen.hdash.domain.Price;
import com.despegar.examen.hdash.domain.Response;
import com.despegar.examen.hdash.domain.Scope;
import com.despegar.examen.hdash.repository.ApiClient;
import com.despegar.examen.hdash.service.GeographyService;
import com.despegar.examen.hdash.service.impl.HotelServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootConfiguration()
public class HotelServiceTest {

	@Mock
	private ApiClient apiClient;

	@Mock
	private GeographyService geographyService;

	@InjectMocks
	private HotelServiceImpl hotelService;

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(hotelService, "hotelApi", "http://despegar.com/hotels");
		ReflectionTestUtils.setField(hotelService, "priceApi", "http://despegar.com/prices");
	}

	@Test
	public void getTotalCountByScopeCitiesTest() throws Exception {

		Response<Hotel> responseHotel = new Response<>();
		List<Hotel> hotels = new ArrayList<>();
		Hotel hotel = new Hotel();
		hotel.setId(1L);
		Location location = new Location();
		location.setId(2L);
		location.setNombre("Dummy");
		location.setCity(new City(1L, 2L));
		hotel.setLocation(location);
		hotels.add(hotel);
		responseHotel.setItems(hotels);
		Mockito.when(apiClient.getResponseDataSync(Mockito.any(UriComponentsBuilder.class), Mockito.eq(Hotel.class)))
				.thenReturn(responseHotel);
		Scope scope = Scope.CITIES;
		Map<String, Long> respuesta = hotelService.getTotalHotelsByScope(scope);
		assertNotNull(respuesta);
		assertTrue(respuesta.containsKey("1"));

	}

	@Test
	public void getTotalOfAvailabilitiesHotelsByScope() throws Exception {

		Response<Hotel> responseHotel = new Response<>();
		List<Hotel> hotels = new ArrayList<>();
		Hotel hotel = new Hotel();
		hotel.setId(1L);
		Location location = new Location();
		location.setId(2L);
		location.setNombre("Dummy");
		location.setCity(new City(1L, 2L));
		hotel.setLocation(location);
		hotels.add(hotel);
		responseHotel.setItems(hotels);

		Response<Price> responsePrice = new Response<>();
		List<Price> hotelPrice = new ArrayList<>();
		Price hotelPrice1 = new Price("1|562|AR", 2L, null, null);
		Price hotelPrice2 = new Price("1|555|AR", 1L, null, null);
		hotelPrice.add(hotelPrice1);
		hotelPrice.add(hotelPrice2);
		responsePrice.setItems(hotelPrice);

		Mockito.when(apiClient.getResponseDataSync(Mockito.any(UriComponentsBuilder.class), Mockito.eq(Hotel.class)))
				.thenReturn(responseHotel);
		Mockito.when(apiClient.getResponseDataSync(Mockito.any(UriComponentsBuilder.class), Mockito.eq(Price.class)))
				.thenReturn(responsePrice);
		Scope scope = Scope.CITIES;

		Long[] destinations = { 1L, 2L };

		AvailabilitiesHotelWrapper respuesta = hotelService.getTotalOfAvailabilitiesHotelsByScope(destinations, scope);

		assertNotNull(respuesta);
	}

}
