package com.despegar.examen.hdash.repository;

import static org.junit.Assert.assertFalse;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.util.List;

import org.apache.http.impl.client.HttpClientBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.despegar.examen.hdash.domain.Continent;
import com.despegar.examen.hdash.domain.Hotel;
import com.despegar.examen.hdash.domain.Price;
import com.despegar.examen.hdash.domain.Response;

@RunWith(SpringRunner.class)
@SpringBootTest
@SpringBootConfiguration()
public class ApiClientTest {

	private MockRestServiceServer mockServer;

	@Value("${hotel.service.api.url}")
	private String hotelApi;

	@Value("${price.service.api.url}")
	private String priceApi;

	@Value("${city.service.api.url}")
	private String cityApi;

	@Value("${country.service.api.url}")
	private String countryApi;

	@Value("${continent.service.api.url}")
	private String continentApi;

	private ApiClient apiClient;

	@Before
	public void setup() {
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
				HttpClientBuilder.create().build());
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
		this.mockServer = MockRestServiceServer.createServer(restTemplate);
		apiClient = new ApiClient(restTemplate);
	}

	@Test
	public void testGetDataSyncByHotel() throws Exception {
		String mockResponseBody = "{\"items\":[{\"id\":\"200001\",\"published\":true,\"test\":false,\"name\":\"Super8Ogallala\",\"hotel_type\":{\"id\":\"HOT\"},\"stars\":2,\"location\":{\"city\":{\"id\":\"5296\"},\"address\":\"500EastAStreetSouth\",\"zipcode\":\"69153-3111\",\"latitude\":41.11161,\"longitude\":-101.71544},\"checkin\":{\"from\":\"13:00\"},\"checkout\":{\"to\":\"11:00\"},\"main_picture\":{\"url\":\"http://media.staticontent.com/media/pictures/734f659f-2e8e-456b-8493-8de3f30a4cdb\",\"id\":\"734f659f-2e8e-456b-8493-8de3f30a4cdb\",\"width\":381,\"height\":290,\"order\":0,\"picture_category\":{\"id\":\"1\"}},\"number_of_rooms\":91,\"creation_date\":\"2010-01-19T00:08:26.000Z\",\"last_modified_date\":\"2017-09-26T18:00:58.000Z\"},{\"id\":\"200002\",\"published\":true,\"test\":false,\"name\":\"Super8Ogden\",\"hotel_type\":{\"id\":\"HOT\"},\"stars\":2,\"location\":{\"city\":{\"id\":\"2820\"},\"address\":\"1508W2100S\",\"zipcode\":\"84401\",\"latitude\":41.22877,\"longitude\":-112.01663},\"checkin\":{\"from\":\"15:00\"},\"checkout\":{\"to\":\"11:00\"},\"main_picture\":{\"url\":\"http://media.staticontent.com/media/pictures/079b42f6-7599-497c-b115-8ab6c2d0cb13\",\"id\":\"079b42f6-7599-497c-b115-8ab6c2d0cb13\",\"width\":378,\"height\":288,\"order\":0,\"picture_category\":{\"id\":\"0\"}},\"number_of_rooms\":58,\"creation_date\":\"2010-01-19T00:08:26.000Z\",\"last_modified_date\":\"2017-09-11T04:00:06.000Z\"}],\"paging\":{\"offset\":0,\"limit\":2,\"total\":354249}}";
		UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(hotelApi).queryParam("offset", 0)
				.queryParam("limit", 2);
		this.mockServer.expect(requestTo(uriComponentsBuilder.build().encode().toUri()))
				.andExpect(method(HttpMethod.GET))
				.andRespond(withSuccess(mockResponseBody, MediaType.APPLICATION_JSON));
		Response<Hotel> response = apiClient.getResponseDataSync(uriComponentsBuilder, Hotel.class);
		this.mockServer.verify();
		assertFalse(response.getItems().isEmpty());
	}

	@Test
	public void testGetDataSyncByHotelPrice() throws Exception {
		String mockResponseBody = "{\"items\":[{\"id\":\"site|AR|982|2|2|346552|2018-01-01|11|BRB|at_destination|2017-10-30T16:48:11\",\"hotel_id\":\"346552\",\"checkin_date\":\"2018-01-01\",\"checkout_date\":\"2018-01-12\",\"payment_types\":[\"at_destination\"],\"max_installment_quantity\":1,\"contract_currency\":\"USD\",\"contract_currency_rate\":1,\"meal_plan\":{\"id\":\"BRB\"},\"price_detail\":{\"currency\":\"USD\",\"subtotal\":120.12,\"taxes\":20.43,\"taxes_detail\":[{\"code\":\"base\",\"amount\":20.43}],\"fee\":4,\"discounts\":0,\"total\":145.34,\"nightly\":{\"subtotal\":10.92,\"total\":13.21}},\"context\":\"hotel\",\"fully_refundable\":false},{\"id\":\"site|AR|4544|2|5|639275|2017-11-20|3|BRC|at_destination,prepaid_installments,prepaid_one_payment|2017-10-31T23:54:41\",\"hotel_id\":\"639275\",\"checkin_date\":\"2017-11-20\",\"checkout_date\":\"2017-11-23\",\"payment_types\":[\"prepaid_installments\",\"at_destination\",\"prepaid_one_payment\"],\"max_installment_quantity\":50,\"contract_currency\":\"USD\",\"contract_currency_rate\":1,\"meal_plan\":{\"id\":\"BRC\"},\"price_detail\":{\"currency\":\"USD\",\"subtotal\":126.69,\"taxes\":20.28,\"taxes_detail\":[{\"code\":\"base\",\"amount\":20.28}],\"fee\":0,\"discounts\":0,\"total\":146.97,\"nightly\":{\"subtotal\":42.23,\"total\":48.99}},\"context\":\"hotel\",\"fully_refundable\":false}]}";
		UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(priceApi)
				.queryParam("country", "AR").queryParam("destination", "982,4544");
		this.mockServer.expect(requestTo(uriComponentsBuilder.build().encode().toUri()))
				.andExpect(method(HttpMethod.GET))
				.andRespond(withSuccess(mockResponseBody, MediaType.APPLICATION_JSON));
		Response<Price> response = apiClient.getResponseDataSync(uriComponentsBuilder, Price.class);

		this.mockServer.verify();
		assertFalse(response.getItems().isEmpty());
	}


	@Test
	public void testGetDataSyncByContinents() throws Exception {
		String mockResponseBody = "[{\"id\":\"30006\",\"gid\":\"CON_30006\",\"descriptions\":{\"es\":\"Europa\"},\"last_update_date\":\"2014-09-17T04:00:00Z\",\"code\":\"EU\",\"pictures\":[]},{\"id\":\"34398\",\"gid\":\"CON_34398\",\"descriptions\":{\"es\":\"Oceanía\"},\"last_update_date\":\"2014-09-17T04:00:00Z\",\"code\":\"OC\",\"pictures\":[]},{\"id\":\"30001\",\"gid\":\"CON_30001\",\"descriptions\":{\"es\":\"AméricaCentralyCaribe\"},\"last_update_date\":\"2014-09-17T04:00:00Z\",\"code\":\"AMC\",\"pictures\":[]},{\"id\":\"30004\",\"gid\":\"CON_30004\",\"descriptions\":{\"es\":\"AméricadelNorte\"},\"last_update_date\":\"2014-09-17T04:00:00Z\",\"code\":\"NA\",\"pictures\":[]},{\"id\":\"30003\",\"gid\":\"CON_30003\",\"descriptions\":{\"es\":\"AméricadelSur\"},\"last_update_date\":\"2014-09-17T04:00:00Z\",\"code\":\"SA\",\"pictures\":[]},{\"id\":\"30005\",\"gid\":\"CON_30005\",\"descriptions\":{\"es\":\"Asia\"},\"last_update_date\":\"2014-09-17T04:00:00Z\",\"code\":\"AS\",\"pictures\":[]},{\"id\":\"34399\",\"gid\":\"CON_34399\",\"descriptions\":{\"es\":\"Antártida\"},\"last_update_date\":\"2014-09-17T04:00:00Z\",\"code\":\"AN\",\"pictures\":[]},{\"id\":\"30002\",\"gid\":\"CON_30002\",\"descriptions\":{\"es\":\"África\"},\"last_update_date\":\"2014-09-17T04:00:00Z\",\"code\":\"AF\",\"pictures\":[]}]";
		UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(continentApi)
				.queryParam("language", "es");
		;
		this.mockServer.expect(requestTo(uriComponentsBuilder.build().encode().toUri()))
				.andExpect(method(HttpMethod.GET))
				.andRespond(withSuccess(mockResponseBody, MediaType.APPLICATION_JSON));
		List<Continent> list = apiClient.getListDataSync(uriComponentsBuilder, Continent.class);

		this.mockServer.verify();
		assertFalse(list.isEmpty());
	}

}
