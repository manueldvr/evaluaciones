package com.despegar.examen.hdash.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.despegar.examen.hdash.domain.AvailabilitiesHotelWrapper;
import com.despegar.examen.hdash.domain.City;
import com.despegar.examen.hdash.domain.Country;
import com.despegar.examen.hdash.domain.Hotel;
import com.despegar.examen.hdash.domain.Location;
import com.despegar.examen.hdash.domain.Price;
import com.despegar.examen.hdash.domain.Response;
import com.despegar.examen.hdash.domain.Scope;
import com.despegar.examen.hdash.exception.ResourceNotFoundException;
import com.despegar.examen.hdash.repository.ApiClient;
import com.despegar.examen.hdash.service.GeographyService;
import com.despegar.examen.hdash.service.HotelService;

/**
 * The Class HotelServiceImpl.
 */
@Service
public class HotelServiceImpl implements HotelService {

	private static final Logger LOG = LoggerFactory.getLogger(HotelServiceImpl.class);

	@Value("${hotel.service.api.url}")
	private String hotelApi;

	@Value("${price.service.api.url}")
	private String priceApi;

	@Autowired
	private ApiClient apiClient;

	@Autowired
	private GeographyService geographyService;

	private List<Hotel> hotelList;

	private List<Price> hotelListPrice;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.despegar.examen.hdash.service.HotelService#getTotalHotelsByScope(com.
	 * despegar.examen.hdash.domain.Scope)
	 */
	@Override
	public Map<String, Long> getTotalHotelsByScope(Scope scope) {

		hotelList = null;
		LOG.info("Get total hotels by scope : {}", scope);
		IntStream.iterate(0, i -> i + 200).limit(5).forEach(i -> loadHotelList(i));

		LOG.info("Counting hotels grouping by locations");
		Map<Location, Long> mapLocationCounts = hotelList.stream()
				.collect(Collectors.groupingBy(Hotel::getLocation, Collectors.counting()));

		switch (scope) {
		case CITIES:
			Map<String, Long> mapCity = mapLocationCounts.entrySet().stream().collect(
					Collectors.toMap(e -> ((Location) e.getKey()).getCity().getId().toString(), e -> e.getValue()));
			LOG.info("Sorting list");
			return mapCity.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed())
					.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
		case COUNTRIES:
			Map<String, Long> mapCountry = getMapCountry(mapLocationCounts);
			LOG.info("Sorting list");
			return mapCountry.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed())
					.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
		case CONTINENTS:
			Map<String, Long> mapCountryCount = getMapContinent(mapLocationCounts);
			LOG.info("Sorting list");
			return mapCountryCount.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed())
					.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
		default:
			throw new ResourceNotFoundException();
		}
	}

	/**
	 * Gets the map continent.
	 *
	 * @param mapLocationCounts
	 *            the map location counts
	 * @return the map continent
	 */
	private Map<String, Long> getMapContinent(Map<Location, Long> mapLocationCounts) {
		Map<String, Long> mapCountryCount = getMapCountry(mapLocationCounts);

		LOG.info("Creating map<id,total> with cities ids and hotels count...");
		Map<Long, Long> mapCountryWithTotalCount = mapCountryCount.entrySet().stream()
				.collect(Collectors.toMap(e -> Long.parseLong(e.getKey()), e -> e.getValue()));
		List<Long> countryIdFiltered = mapCountryWithTotalCount.keySet().stream().collect(Collectors.toList());

		LOG.info("Filtered country list by id for obtaining continent_id...");
		List<Country> countryListComplete = geographyService.getAllCountries();
		Predicate<Country> countryHasSameId = c -> countryIdFiltered.stream().anyMatch(u -> u.equals(c.getId()));
		List<Country> countryFiltered = countryListComplete.stream().filter(countryHasSameId)
				.collect(Collectors.toList());

		LOG.info("Grouping filtered country by continents...");
		Map<Long, List<Country>> continentList = countryFiltered.stream()
				.collect(Collectors.groupingBy(Country::getContinentId));

		LOG.info("Adding values to response");
		Map<String, Long> mapContinent = new HashMap<>();
		continentList.forEach((key, value) -> {
			value.forEach((c) -> {
				mapContinent.put(key.toString(),
						getSumById(mapCountryWithTotalCount, c.getId(), mapContinent.get(key.toString())));
			});

		});
		return mapContinent;
	}

	/**
	 * Load hotel list.
	 *
	 * @param limit
	 *            the limit
	 */
	private void loadHotelList(int limit) {
		Response<Hotel> response = apiClient.getResponseDataSync(buildRequestHotel(limit, limit + 200), Hotel.class);
		if (this.hotelList != null)
			this.hotelList.addAll(response.getItems());
		else
			hotelList = response.getItems();
	}

	/**
	 * Load hotel list by price.
	 *
	 * @param destinations
	 *            the destinations
	 * @param country
	 *            the country
	 */
	private void loadHotelListByPrice(Long[] destinations, int n) {
		Long[] partialDestination = getPartialDestinationList(destinations, n);
		String destinationsParam = Arrays.stream(partialDestination).map(i -> ((Long) i).toString())
				.collect(Collectors.joining(", "));
		Response<Price> response = apiClient.getResponseDataSync(buildRequestHotelByPrice(destinationsParam),
				Price.class);
		if (this.hotelListPrice != null)
			this.hotelListPrice.addAll(response.getItems());
		else
			hotelListPrice = response.getItems();
	}

	/**
	 * Gets the map country.
	 *
	 * @param mapLocationCounts
	 *            the map location counts
	 * @return the map country
	 */
	private Map<String, Long> getMapCountry(Map<Location, Long> mapLocationCounts) {
		LOG.info("Creating map<id,total> with cities ids and hotels count...");
		Map<Long, Long> mapCityWithTotalCount = mapLocationCounts.entrySet().stream()
				.collect(Collectors.toMap(e -> ((Location) e.getKey()).getCity().getId(), e -> e.getValue()));
		List<Long> cityIdFiltered = mapCityWithTotalCount.keySet().stream().collect(Collectors.toList());

		LOG.info("Filtered city list by id for obtaining country_id...");
		List<City> cityList = geographyService.getAllCities();
		Predicate<City> hasSameId = c -> cityIdFiltered.stream().anyMatch(u -> u.equals(c.getId()));
		List<City> cityFiltered = cityList.stream().filter(hasSameId).collect(Collectors.toList());

		LOG.info("Grouping filtered cities by countries...");
		Map<Long, List<City>> countryList = cityFiltered.stream().collect(Collectors.groupingBy(City::getCountryId));

		LOG.info("Adding values to response");
		Map<String, Long> mapCountry = new HashMap<>();
		countryList.forEach((key, value) -> {
			value.forEach((c) -> {
				mapCountry.put(key.toString(),
						getSumById(mapCityWithTotalCount, c.getId(), mapCountry.get(key.toString())));
			});

		});
		return mapCountry;
	}

	/**
	 * Gets the total by country id.
	 *
	 * @param mapIdCount
	 *            the map city with total count
	 * @param id
	 *            the id
	 * @param sum
	 *            the sum
	 * @return the total by country id
	 */
	private Long getSumById(Map<Long, Long> mapIdCount, Long id, Long sum) {
		if (sum == null)
			return mapIdCount.get(id);
		else {
			return sum + mapIdCount.get(id);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.despegar.examen.hdash.service.HotelService#
	 * getTotalOfAvailabilitiesHotelsByScope(java.lang.Long[],
	 * com.despegar.examen.hdash.domain.Scope)
	 */
	@Override
	public AvailabilitiesHotelWrapper getTotalOfAvailabilitiesHotelsByScope(Long[] destinations, Scope scope) {

		hotelList = null;
		LOG.info("Get total hotels by scope : {}", scope);
		IntStream.iterate(0, i -> i + 200).limit(5).forEach(i -> loadHotelList(i));

		LOG.info("Get hotels price by destinations");
		int limit = determineLimit(destinations);
		hotelListPrice = null;
		IntStream.iterate(0, i -> i + 1).limit(limit).forEach(i -> loadHotelListByPrice(destinations, i));

		LOG.info("Get list of hotels ids with availables...");
		List<Long> hotelAvailables = hotelListPrice.stream().map(Price::getHotelId).collect(Collectors.toList());

		LOG.info("Filtering hotels by destinations param ...");
		List<Long> listDestinations = Arrays.asList(destinations);
		List<Hotel> hotelsFilteredByDestinations = hotelList.stream()
				.filter(c -> listDestinations.contains(c.getLocation().getCity().getId())).collect(Collectors.toList());

		LOG.info("Filtering hotels availables...");
		List<Hotel> hotelsFilteredByDestinationsAvailables = hotelsFilteredByDestinations.stream()
				.filter(c -> hotelAvailables.contains(c.getId())).collect(Collectors.toList());

		LOG.info("Filtering hotel without unavailables by destinations...");
		List<Hotel> hotelsFilteredByDestinationsUnavailables = hotelsFilteredByDestinations.stream()
				.filter(c -> hotelAvailables.contains(c.getId())).collect(Collectors.toList());
		List<String> destinationUnavailables = hotelsFilteredByDestinationsUnavailables.stream()
				.map(m -> m.getLocation().getCity().getId().toString()).collect(Collectors.toList());

		LOG.info("Counting hotels grouping by locations");
		Map<Location, Long> mapLocationCounts = hotelsFilteredByDestinationsAvailables.stream()
				.collect(Collectors.groupingBy(Hotel::getLocation, Collectors.counting()));

		switch (scope) {
		case CITIES:
			Map<String, Long> mapCity = mapLocationCounts.entrySet().stream().collect(
					Collectors.toMap(e -> ((Location) e.getKey()).getCity().getId().toString(), e -> e.getValue()));
			return new AvailabilitiesHotelWrapper(mapCity, destinationUnavailables);
		case COUNTRIES:
			Map<String, Long> mapCountry = getMapCountry(mapLocationCounts);
			return new AvailabilitiesHotelWrapper(mapCountry, destinationUnavailables);
		case CONTINENTS:
			Map<String, Long> mapCountryCount = getMapContinent(mapLocationCounts);
			return new AvailabilitiesHotelWrapper(mapCountryCount, destinationUnavailables);
		default:
			throw new ResourceNotFoundException();
		}

	}

	/**
	 * Determine limit of iterations, the service only accept 3 params
	 *
	 * @param destinations
	 *            the destinations
	 * @return the int
	 */
	private int determineLimit(Long[] destinations) {
		int limit = 1;
		if (destinations.length > 3 && destinations.length <= 6)
			limit = 2;
		else if (destinations.length > 6 && destinations.length <= 9)
			limit = 3;
		else if (destinations.length > 9)
			limit = 4;
		return limit;
	}

	/**
	 * Gets the partial destination list.
	 *
	 * @param destinations
	 *            the destinations
	 * @return the partial destination list
	 */
	private Long[] getPartialDestinationList(Long[] destinations, int iteration) {
		if (iteration == 0)
			if (destinations.length <= 3)
				return Arrays.copyOfRange(destinations, 0, destinations.length);
			else
				return Arrays.copyOfRange(destinations, 0, 3);
		else if (iteration == 1)
			if (destinations.length <= 6)
				return Arrays.copyOfRange(destinations, 3, destinations.length);
			else
				return Arrays.copyOfRange(destinations, 3, 6);

		else if (iteration == 2)
			if (destinations.length <= 9)
				return Arrays.copyOfRange(destinations, 6, destinations.length);
			else
				return Arrays.copyOfRange(destinations, 6, 9);
		else
			return Arrays.copyOfRange(destinations, 9, destinations.length);
	}

	/**
	 * Builds the request hotel by price.
	 *
	 * @param destinations
	 *            the destinations
	 * @param country
	 *            the country
	 * @return the uri components builder
	 */
	private UriComponentsBuilder buildRequestHotelByPrice(String destinations) {
		UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(priceApi)
				.queryParam("country", "AR").queryParam("destinations", destinations);
		return uriComponentsBuilder;
	}

	/**
	 * Builds the request hotel.
	 *
	 * @param offset
	 *            the offset
	 * @param limit
	 *            the limit
	 * @return the uri components builder
	 */
	private UriComponentsBuilder buildRequestHotel(int offset, int limit) {
		UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(hotelApi)
				.queryParam("offset", offset).queryParam("limit", limit);
		return uriComponentsBuilder;
	}

}
