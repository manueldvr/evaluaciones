package com.despegar.examen.hdash.domain;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The Class Location.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Location {

	private Long id;
	private String nombre;
	private City city;

	public Location() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Location [id=" + id + ", nombre=" + nombre + ", city=" + city + "]";
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Location)) {
			return false;
		}
		Location location = (Location) o;
		return location.id == id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, nombre, city);
	}

}
