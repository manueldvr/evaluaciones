/**
 *  Exceptions components for error manipulation.
 * 
 * @author emilio.watemberg
 */
package com.despegar.examen.hdash.exception;
