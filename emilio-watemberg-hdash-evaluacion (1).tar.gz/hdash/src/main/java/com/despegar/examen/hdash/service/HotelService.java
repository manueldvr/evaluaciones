package com.despegar.examen.hdash.service;

import java.util.Map;

import com.despegar.examen.hdash.domain.AvailabilitiesHotelWrapper;
import com.despegar.examen.hdash.domain.Scope;

/**
 * The Interface HotelService.
 */
public interface HotelService {

	/**
	 * Gets the total hotels by scope.
	 *
	 * @param scope
	 *            the scope
	 * @return the total hotels by scope
	 */
	Map<String, Long> getTotalHotelsByScope(Scope scope);

	/**
	 * Gets the total of availabilities hotels by scope.
	 *
	 * @param destinations
	 *            the destinations
	 * @param scope
	 *            the scope
	 * @return the total of availabilities hotels by scope
	 */
	AvailabilitiesHotelWrapper getTotalOfAvailabilitiesHotelsByScope(Long[] destinations, Scope scope);

}
