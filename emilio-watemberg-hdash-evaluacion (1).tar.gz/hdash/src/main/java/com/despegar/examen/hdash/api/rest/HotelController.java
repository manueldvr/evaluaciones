package com.despegar.examen.hdash.api.rest;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.despegar.examen.hdash.api.rest.util.HeaderUtil;
import com.despegar.examen.hdash.domain.AvailabilitiesHotelWrapper;
import com.despegar.examen.hdash.domain.Scope;
import com.despegar.examen.hdash.service.HotelService;

/**
 * REST controller for managing hotel.
 */
@RestController
@RequestMapping("/dashboard")
public class HotelController {

	private static final Logger LOG = LoggerFactory.getLogger(HotelController.class);

	private static final String ENTITY_NAME = "hotelManagement";

	@Autowired
	private HotelService hotelService;

	/**
	 * GET /hotels : List total count hotels by scope (city, country or continent)
	 *
	 * @param scope
	 *            the scope of search
	 * @return the ResponseEntity with status 201 (Created) and with body the list
	 *         of total count hotels, or with status 400 (Bad Request) if the scope
	 *         doesn't exist
	 * @throws URISyntaxException
	 *             if the Location URI syntax is incorrect
	 */
	@GetMapping("/hotels")
	public ResponseEntity<List<Map<String, Long>>> getTotalCountByScope(@RequestParam("scope") String scope)
			throws URISyntaxException {
		LOG.info("REST request to sum total count hotels by scope : {}", scope);
		if (scope.equals(null)) {
			return ResponseEntity.badRequest().headers(
					HeaderUtil.createFailureAlert(ENTITY_NAME, "param-error", "The request should have an scope"))
					.body(null);
		}

		List<Map<String, Long>> list = new ArrayList<>();
		Map<String, Long> map = hotelService.getTotalHotelsByScope(Scope.valueOf(scope.toUpperCase()));
		list.add(map);
		return new ResponseEntity<List<Map<String, Long>>>(list, HttpStatus.OK);
	}

	/**
	 * GET /availabilities : List total count hotels by scope (city, country or
	 * continent) and disponibility.
	 *
	 * @param scope
	 *            the scope of search
	 * @param destinations
	 *            the destinations
	 * @return the ResponseEntity with status 201 (Created) and with body the list
	 *         of total count hotels, or with status 400 (Bad Request) if the scope
	 *         doesn't exist
	 * @throws URISyntaxException
	 *             if the Location URI syntax is incorrect
	 */
	@GetMapping("/availabilities")
	public ResponseEntity<List<AvailabilitiesHotelWrapper>> getAvailabilitiesByScope(
			@RequestParam("scope") String scope, @RequestParam("destinations") Long[] destinations)
			throws URISyntaxException {
		LOG.info("REST request to sum total count hotels by scope : {}", scope);
		if (scope.equals(null) || destinations.equals(null) || destinations.length > 10) {
			return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert(ENTITY_NAME, "param-error",
					"The request should have an scope or/and destination/s")).body(null);
		}

		AvailabilitiesHotelWrapper availabilities = hotelService.getTotalOfAvailabilitiesHotelsByScope(destinations,
				Scope.valueOf(scope.toUpperCase()));
		List<AvailabilitiesHotelWrapper> listAvailabilities = new ArrayList<>();
		listAvailabilities.add(availabilities);
		return new ResponseEntity<List<AvailabilitiesHotelWrapper>>(listAvailabilities, HttpStatus.OK);
	}

}
