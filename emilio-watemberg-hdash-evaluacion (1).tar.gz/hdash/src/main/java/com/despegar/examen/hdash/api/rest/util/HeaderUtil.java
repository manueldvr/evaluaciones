package com.despegar.examen.hdash.api.rest.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;

/**
 * Utility class for HTTP headers creation.
 */
public final class HeaderUtil {

	private static final Logger LOG = LoggerFactory.getLogger(HeaderUtil.class);

	private HeaderUtil() {
	}

	public static HttpHeaders createAlert(String message, String param) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("X-hdash-alert", message);
		headers.add("X-hdash-params", param);
		return headers;
	}

	public static HttpHeaders createFailureAlert(String entityName, String errorKey, String defaultMessage) {
		LOG.error("Request processing failed, {}", defaultMessage);
		HttpHeaders headers = new HttpHeaders();
		headers.add("X-hdash-error", "error." + errorKey);
		headers.add("X-hdash-params", entityName);
		return headers;
	}
}
