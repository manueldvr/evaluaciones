package com.despegar.examen.hdash.repository;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.despegar.examen.hdash.domain.City;
import com.despegar.examen.hdash.domain.Continent;
import com.despegar.examen.hdash.domain.Country;
import com.despegar.examen.hdash.domain.Hotel;
import com.despegar.examen.hdash.domain.Price;
import com.despegar.examen.hdash.domain.Response;

/**
 * The Class ApiClient.
 */
@Component
public class ApiClient {

	private static final Logger LOG = LoggerFactory.getLogger(ApiClient.class);

	@Value("${api.key}")
	private String apiKey;

	HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
			HttpClientBuilder.create().build());

	RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);

	public final HashMap<Class, ParameterizedTypeReference> paramTypeRefMap = new HashMap<>();

	/**
	 * Instantiates a new api client.
	 */
	public ApiClient() {
		initFactoryParameterizedTypeReference();
	}

	/**
	 * Instantiates a new api client.
	 *
	 * @param restTemplate
	 *            the rest template
	 */
	public ApiClient(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
		initFactoryParameterizedTypeReference();
	}

	/**
	 * Gets data in {@link Response} object from rest service.
	 * 
	 * WARNING: {@link ParameterizedTypeReference} no admite el uso de genericos, es
	 * decir, no puede deserializar el json response de un super de T. Ver
	 * documentacion adjunta en readme.
	 *
	 * @param <T>
	 *            the generic type
	 * @param uriComponentsBuilder
	 *            the uri components builder
	 * @param clazz
	 *            the clazz
	 * @return the data sync
	 */
	public <T> Response<T> getResponseDataSync(UriComponentsBuilder uriComponentsBuilder, Class<T> clazz) {
		HttpEntity<?> entity = loadHeaders();

		ParameterizedTypeReference<Response<T>> parameterizedTypeReference = paramTypeRefMap.get(clazz);
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter(Charset.forName("UTF-8")));
		ResponseEntity<Response<T>> responseEntity = restTemplate.exchange(
				uriComponentsBuilder.build().encode().toUri(), HttpMethod.GET, entity, parameterizedTypeReference);

		Response<T> response = responseEntity.getBody();
		MediaType contentType = responseEntity.getHeaders().getContentType();
		HttpStatus statusCode = responseEntity.getStatusCode();

		LOG.info("JSON statusCode : {} contentType : {} ", statusCode, contentType);
		LOG.debug("JSON response : {}", response);
		return response;

	}

	/**
	 * Gets list data from rest service.
	 * 
	 * WARNING: {@link ParameterizedTypeReference} no admite el uso de genericos, es
	 * decir, no puede deserializar el json response de un super de T. Ver
	 * documentacion adjunta en readme.
	 *
	 * @param <T>
	 *            the generic type
	 * @param uriComponentsBuilder
	 *            the uri components builder
	 * @param clazz
	 *            the clazz
	 * @return the list data sync
	 */
	public <T> List<T> getListDataSync(UriComponentsBuilder uriComponentsBuilder, Class<T> clazz) {
		HttpEntity<?> entity = loadHeaders();

		ParameterizedTypeReference<List<T>> parameterizedTypeReference = paramTypeRefMap.get(clazz);
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter(Charset.forName("UTF-8")));
		ResponseEntity<List<T>> responseEntity = restTemplate.exchange(uriComponentsBuilder.build().encode().toUri(),
				HttpMethod.GET, entity, parameterizedTypeReference);

		List<T> response = responseEntity.getBody();
		MediaType contentType = responseEntity.getHeaders().getContentType();
		HttpStatus statusCode = responseEntity.getStatusCode();

		LOG.info("JSON statusCode : {} contentType : {} ", statusCode, contentType);
		//LOG.debug("JSON response : {}", response);
		return response;
	}

	/**
	 * Load headers.
	 *
	 * @return the http entity
	 */
	private HttpEntity<?> loadHeaders() {
		LOG.info("Retrieving data from service synchronously...");
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("Accept-Encoding", "gzip");
		headers.add("Content-Encoding", "gzip");
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		headers.add("X-ApiKey", "c6f65de19e5749acbff0cebe37a43174");
		HttpEntity<?> entity = new HttpEntity<>(headers);
		LOG.debug("Headers : {}", entity.getHeaders());
		return entity;
	}

	/**
	 * Inits the factory map to parameterized type reference.
	 * 
	 */
	private void initFactoryParameterizedTypeReference() {
		paramTypeRefMap.put(Hotel.class, new ParameterizedTypeReference<Response<Hotel>>() {
		});
		paramTypeRefMap.put(Price.class, new ParameterizedTypeReference<Response<Price>>() {
		});
		paramTypeRefMap.put(City.class, new ParameterizedTypeReference<List<City>>() {
		});
		paramTypeRefMap.put(Country.class, new ParameterizedTypeReference<List<Country>>() {
		});
		paramTypeRefMap.put(Continent.class, new ParameterizedTypeReference<List<Continent>>() {
		});
	}

}
