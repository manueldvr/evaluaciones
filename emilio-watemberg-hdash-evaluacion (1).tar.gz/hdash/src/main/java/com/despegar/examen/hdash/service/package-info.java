/**
 * Business logic abstractions, this layer has no idea how to communicate with datasource.
 * 
 * @author emilio.watemberg
 */
package com.despegar.examen.hdash.service;
