package com.despegar.examen.hdash.service;

import java.util.List;

import com.despegar.examen.hdash.domain.City;
import com.despegar.examen.hdash.domain.Continent;
import com.despegar.examen.hdash.domain.Country;

/**
 * The Interface GeographyService.
 */
public interface GeographyService {

	/**
	 * Gets the all cities.
	 *
	 * @return the all cities
	 */
	List<City> getAllCities();

	/**
	 * Gets the all countries.
	 *
	 * @return the all countries
	 */
	List<Country> getAllCountries();

	/**
	 * Gets the all continents.
	 *
	 * @return the all continents
	 */
	List<Continent> getAllContinents();

}
