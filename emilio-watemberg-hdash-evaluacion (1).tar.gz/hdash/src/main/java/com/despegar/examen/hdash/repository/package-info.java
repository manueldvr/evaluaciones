/**
 * Rest Client for Data access components to hotels information.
 * 
 * @author emilio.watemberg
 */
package com.despegar.examen.hdash.repository;
