/**
 * Domain classes used to produce the JSON for the RESTful services.
 * 
 * @author emilio.watemberg
 */
package com.despegar.examen.hdash.domain;
