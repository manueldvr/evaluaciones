package com.despegar.examen.hdash.api.rest;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * The Class CustomErrorController.
 */
@RestController
public class CustomErrorController implements ErrorController {

	private static final String PATH = "/error";
	private static final Logger LOG = Logger.getLogger(CustomErrorController.class);

	@Autowired
	private ErrorAttributes errorAttributes;

	/** The debug. */
	@Value("${application.debug}")
	private boolean debug;

	@Override
	public String getErrorPath() {
		return PATH;
	}

	/**
	 * Error.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the map
	 */
	@RequestMapping(value = PATH)
	public Map<String, Object> error(HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> map = new HashMap<>();
		map.put("status", response.getStatus());
		map.put("reason", getErrorAttributes(request, debug));
		LOG.warn(map);
		return map;
	}

	/**
	 * Gets the error attributes.
	 *
	 * @param request
	 *            the request
	 * @param includeStackTrace
	 *            the include stack trace
	 * @return the error attributes
	 */
	private Map<String, Object> getErrorAttributes(HttpServletRequest request, boolean includeStackTrace) {
		RequestAttributes requestAttributes = new ServletRequestAttributes(request);
		return errorAttributes.getErrorAttributes(requestAttributes, includeStackTrace);
	}
}