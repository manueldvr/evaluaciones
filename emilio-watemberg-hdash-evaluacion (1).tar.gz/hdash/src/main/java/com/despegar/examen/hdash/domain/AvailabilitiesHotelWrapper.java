package com.despegar.examen.hdash.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The Class AvailabilitiesHotelWrapper.
 */
public class AvailabilitiesHotelWrapper {

	List<Map<String, Long>> availables = new ArrayList<>();
	List<String> unavailables = new ArrayList<>();

	public AvailabilitiesHotelWrapper() {
		super();
	}

	public AvailabilitiesHotelWrapper(Map<String, Long> map, List<String> totalHotels) {
		super();
		availables.add(map);
		unavailables = totalHotels;
	}

	public List<Map<String, Long>> getAvailables() {
		return availables;
	}

	public void setAvailables(List<Map<String, Long>> availables) {
		this.availables = availables;
	}

	public List<String> getUnavailables() {
		return unavailables;
	}

	public void setUnavailables(List<String> unavailables) {
		this.unavailables = unavailables;
	}

}
