package com.despegar.examen.hdash.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The Class Hotel.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Hotel {

	private Long id;
	private boolean published;
	private Location location;

	public Hotel() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}
	
	

}
