package com.despegar.examen.hdash.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.despegar.examen.hdash.domain.City;
import com.despegar.examen.hdash.domain.Continent;
import com.despegar.examen.hdash.domain.Country;
import com.despegar.examen.hdash.repository.ApiClient;
import com.despegar.examen.hdash.service.GeographyService;

/**
 * The Class GeographyServiceImpl.
 */
@Service
public class GeographyServiceImpl implements GeographyService {

	private static final Logger LOG = LoggerFactory.getLogger(GeographyServiceImpl.class);

	@Value("${city.service.api.url}")
	private String cityApi;

	@Value("${country.service.api.url}")
	private String countryApi;

	@Value("${continent.service.api.url}")
	private String continentApi;

	/** The api client. */
	@Autowired
	private ApiClient apiClient;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.despegar.examen.hdash.service.GeographyService#getAllCities()
	 */
	@Override
	public List<City> getAllCities() {
		LOG.info("Get all cities...");
		List<City> response = apiClient.getListDataSync(buildRequest(cityApi), City.class);
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.despegar.examen.hdash.service.GeographyService#getAllCountries()
	 */
	@Override
	public List<Country> getAllCountries() {
		LOG.info("Get all countries...");
		List<Country> response = apiClient.getListDataSync(buildRequest(countryApi), Country.class);
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.despegar.examen.hdash.service.GeographyService#getAllContinents()
	 */
	@Override
	public List<Continent> getAllContinents() {
		LOG.info("Get all continents...");
		List<Continent> response = apiClient.getListDataSync(buildRequest(continentApi), Continent.class);
		return response;
	}

	/**
	 * Builds the request.
	 *
	 * @param apiUrl
	 *            the api url
	 * @return the uri components builder
	 */
	private UriComponentsBuilder buildRequest(String apiUrl) {
		UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(apiUrl).query("snapshot");
		LOG.info("URL: {}" , uriComponentsBuilder.build().encode().toUri());
		return uriComponentsBuilder;
	}

}
