package com.despegar.examen.hdash.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class Country.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Country {

	private Long id;
	@JsonProperty("continent_id")
	private Long continentId;
	private String code;

	public Country() {
		super();
	}

	public Country(Long id, Long continentId, String code) {
		super();
		this.id = id;
		this.continentId = continentId;
		this.code = code;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getContinentId() {
		return continentId;
	}

	public void setContinentId(Long continentId) {
		this.continentId = continentId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
