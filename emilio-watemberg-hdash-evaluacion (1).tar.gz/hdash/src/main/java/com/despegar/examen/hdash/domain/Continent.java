package com.despegar.examen.hdash.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class Continent.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Continent {

	private Long id;
	private String code;

	public Continent() {
		super();
	}

	public Continent(Long id, String code) {
		super();
		this.id = id;
		this.code = code;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
