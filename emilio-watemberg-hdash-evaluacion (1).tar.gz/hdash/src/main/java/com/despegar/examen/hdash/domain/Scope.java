package com.despegar.examen.hdash.domain;

/**
 * The Enum Scope.
 */
public enum Scope {

	CITIES("cities"), COUNTRIES("countries"), CONTINENTS("continents");

	private final String value;

	/**
	 * Instantiates a new scope.
	 *
	 * @param value
	 *            the value
	 */
	private Scope(final String value) {
		this.value = value;
	}

}
