package com.despegar.examen.hdash.domain;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class City.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class City {

	private Long id;
	@JsonProperty("country_id")
	private Long countryId;

	public City() {
		super();
	}

	public City(Long id, Long countryId) {
		super();
		this.id = id;
		this.countryId = countryId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof City)) {
			return false;
		}
		City city = (City) o;
		return city.id == id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

}
