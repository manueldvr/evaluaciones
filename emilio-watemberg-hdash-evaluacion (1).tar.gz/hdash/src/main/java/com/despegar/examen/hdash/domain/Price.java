package com.despegar.examen.hdash.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class Price.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Price {

	private String id;
	@JsonProperty("hotel_id")
	private Long hotelId;
	@JsonProperty("checkin_date")
	private String checkinDate;
	@JsonProperty("checkout_date")
	private String checkoutDate;

	public Price() {
		super();
	}

	public Price(String id, Long hotelId, String checkinDate, String checkoutDate) {
		super();
		this.id = id;
		this.hotelId = hotelId;
		this.checkinDate = checkinDate;
		this.checkoutDate = checkoutDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public String getCheckinDate() {
		return checkinDate;
	}

	public void setCheckinDate(String checkinDate) {
		this.checkinDate = checkinDate;
	}

	public String getCheckoutDate() {
		return checkoutDate;
	}

	public void setCheckoutDate(String checkoutDate) {
		this.checkoutDate = checkoutDate;
	}

}
