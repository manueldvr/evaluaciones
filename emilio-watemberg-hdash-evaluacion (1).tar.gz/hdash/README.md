# Evaluación técnica - Despegar

Dashboard Hoteles. Esta aplicación expone 2 recursos REST:

1) /dashboards/hotels?scope=(cities,countries,continents)que permite poder sumarizar por ciudad, por país o por continente la cantidad de hoteles ordenado de mayor a menor por cantidad de hoteles.
a. Ejemplo: 

```
Requet: http://localhost:8080/dashboards/hotels?scope=cities
Response:
[
    {
        "30001": 55,
        "30002": 20,
        "30003": 132,
        "30004": 2161,
        "30005": 76,
        "30006": 519,
        "34398": 37
    }
]

```
2) /dashboards/availabilities?destinations={ids}&scope={cities,countries,continents} donde se debe sumarizar los que tuvieron disponibilidad y los que no tuvieron.
a. Ejemplo:

```
Request: http://localhost:8080/dashboards/availabilities?destinations=192518, 53253, 37901, 53262, 45070, 179212, 179213, 179218&scope=continents
Response:
[
    {
        "availables": [
            {
                "30004": 4,
                "34398": 2
            }
        ],
        "unavailables": [
            "53262",
            "53262",
            "179213",
            "192518",
            "179213",
            "192518"
        ]
    }
]
```

## How to Run 

* Si desea, puede compilar el proyecto corriendo ```mvn clean install```
* Una vez finalizado, puede optar por cualquier de estos 2 metodos.

```
        java -jar target/hdash-0.0.1-SNAPSHOT.jar
or
        mvn spring-boot:run

```

* O ejecutando el archivo ```startup.sh``` 

## Acerca del desarrollo.
* Respecto al offset de la lista de hoteles, dado que habia una ambiguedad sobre si usar limit 1000/100/200, opte por hacer 5 llamadas secuenciales de 200.
* En el caso de city/country se utilizó el parametro 'snapshot'.
* Se asumió que los "destinations" son ciudades (no paises ni continentes) ni tampoco hoteles.
* Se uso RestTemplate para consumir la api rest de Despegar.

TODO: 
* Mejorar y ampliar los test, ya que se hicieron al finalizar el ejercicio, para completar cobertura.
* Agregar test de integracion.

## Repo

https://bitbucket.org/emilio_watemberg/hdash


## Preguntas o comentarios: emilio.watemberg@gmail.com